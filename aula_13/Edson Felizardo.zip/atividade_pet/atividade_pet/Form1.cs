﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace atividade_pet
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        animal ani = new animal();
        private void btn_salvar_Click(object sender, EventArgs e)
        {
            try
            {
                ani.setNome(text_nome.Text);
                ani.setEspecie(text_especie.Text);
                ani.setIdade(text_idade.Text);
                ani.setCor(text_cor.Text);
                ani.setSexo(text_sexo.Text);

                ani.inserir();
                dataGridView1.DataSource = ani.Consultar();
            }
            finally {
                MessageBox.Show("Informações gravadas com sucesso");
            }

        }

        private void btn_consultar_Click(object sender, EventArgs e)
        {
            dataGridView1.DataSource = ani.Consultar();
        }

        private void btn_excluir_Click(object sender, EventArgs e)
        {
            ani.setCodigo(tex_codigo.Text);
            ani.excluir();
            dataGridView1.DataSource = ani.Consultar();
        }
    }
}
